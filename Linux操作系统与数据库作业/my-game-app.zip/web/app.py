from flask import Flask, render_template, request, jsonify, session
import psycopg2
import os
import random
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-this'

def get_db():
    return psycopg2.connect(os.environ.get('DATABASE_URL'))

def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS players (
            id SERIAL PRIMARY KEY,
            username VARCHAR(100) UNIQUE NOT NULL,
            total_games INTEGER DEFAULT 0,
            total_wins INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    cur.execute('''
        CREATE TABLE IF NOT EXISTS game_records (
            id SERIAL PRIMARY KEY,
            player_id INTEGER REFERENCES players(id),
            target_number INTEGER,
            attempts INTEGER,
            won BOOLEAN,
            played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    cur.close()
    conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/new_game', methods=['POST'])
def new_game():
    data = request.get_json()
    username = data.get('username')
    
    if not username:
        return jsonify({'error': '请输入用户名'}), 400
    
    target = random.randint(1, 100)
    session['target'] = target
    session['attempts'] = 0
    session['username'] = username
    session['game_over'] = False
    
    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        'INSERT INTO players (username) VALUES (%s) ON CONFLICT (username) DO NOTHING',
        (username,)
    )
    conn.commit()
    cur.close()
    conn.close()
    
    return jsonify({
        'message': '游戏开始！猜一个1-100之间的数字'
    })

@app.route('/api/guess', methods=['POST'])
def guess():
    if session.get('game_over'):
        return jsonify({'error': '游戏已结束，请重新开始'}), 400
    
    data = request.get_json()
    guess_num = data.get('guess')
    target = session.get('target')
    attempts = session.get('attempts', 0) + 1
    username = session.get('username')
    
    if not guess_num:
        return jsonify({'error': '请输入数字'}), 400
    
    session['attempts'] = attempts
    result = ''
    won = False
    
    if guess_num < target:
        result = '太小了！再试试'
    elif guess_num > target:
        result = '太大了！再试试'
    else:
        result = f'🎉 恭喜！你猜对了！用了 {attempts} 次'
        session['game_over'] = True
        won = True
        
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT id FROM players WHERE username = %s', (username,))
        player = cur.fetchone()
        if player:
            cur.execute(
                'INSERT INTO game_records (player_id, target_number, attempts, won) VALUES (%s, %s, %s, %s)',
                (player[0], target, attempts, won)
            )
            cur.execute(
                'UPDATE players SET total_games = total_games + 1, total_wins = total_wins + 1 WHERE id = %s',
                (player[0],)
            )
        conn.commit()
        cur.close()
        conn.close()
    
    return jsonify({
        'result': result,
        'attempts': attempts,
        'game_over': session.get('game_over', False)
    })

@app.route('/api/leaderboard')
def leaderboard():
    conn = get_db()
    cur = conn.cursor()
    cur.execute('''
        SELECT username, total_games, total_wins, 
               ROUND(total_wins * 100.0 / total_games, 2) as win_rate
        FROM players 
        WHERE total_games > 0
        ORDER BY win_rate DESC, total_games DESC
        LIMIT 10
    ''')
    rows = cur.fetchall()
    cur.close()
    conn.close()
    
    leaderboard = []
    for row in rows:
        leaderboard.append({
            'username': row[0],
            'total_games': row[1],
            'total_wins': row[2],
            'win_rate': row[3]
        })
    
    return jsonify(leaderboard)

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)